<?php
require_once 'core/init.php';
require_once 'functions/sanitize.php';

if(Session::exists('home')){
  echo '<p>' .Session::flash('home'). '</p>';
}

$user=new User();

if(!$user->isLoggedIn()){
  Redirect::to('index.php');
}
else{
  if($user->data()->username==null){
    Redirect::to('updateprofile.php');
  }
//remove this after admin script is activated.
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#006cff">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#006cff">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <link href="../letsmit/fonts/fonts.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="../letsmit/css/home.css">
    <link rel="stylesheet" type="text/css" href="../letsmit/css/navbar.css">
    <title>Home</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  </head>
  <body>
    <div class='nav-outer'>
      <nav class='nav-bar'>
        <div class="logo"><p>let's smit</p></div>
        <ul class="center navigation">
          <li><a class='link' href="profile.php?user=<?php echo escape($user->data()->username); ?>">Hello <?php echo escape($user->data()->fname); ?>! <i class="fas fa-caret-down"></i></a>
            <!-- First Tier Drop Down -->
            <ul class="drop">
                <li><a class="link" data-target="profile.php?user=<?php echo escape($user->data()->username); ?>">Profile</a></li>
                <li><a href="updateprofile.php">Update Profile</a></li>
            </ul>
          </li>
          <a class="" href="logout.php"><i class="fas fa-power-off sm"></i></a>
        </ul>
        <div class="icon-container navigation">
          <a class="icon link" data-target="profile.php?user=<?php echo escape($user->data()->username); ?>"><i class="fas fa-user sm"></i></a>
          <a class="icon" href="logout.php"><i class="fas fa-power-off sm"></i></a>
        </div>
      </nav>
    </div>
  <header>
    <div class="navBtn"><p>+</p></div>
    <nav class="sidebar navigation">
      <a class='link' href="landing.php" data-target="frames/landing.php">Home</a>
      <a class='link' href="mess.php" data-target="frames/mess.php">Mess</a>
    </nav>
  </header>


  <div class="main">
    <?php
      require 'frames/landing.php';
     ?>
    <!---php for admin script
        if($user->hasPermission('admin')){
          echo "<p>Administrator</p>";
        }
      }
    else{
      Redirect::to('index.php');
    }
    --->
  </div>
  <div class='bottom-nav navigation'>
    <a href="landing.php" data-target="frames/landing.php" class="link bottom-nav-links" ><i class="fas fa-home"></i></a>
    <a href="mess.php" data-target="frames/mess.php" class="link bottom-nav-links" ><i class="fas fa-hamburger"></i></a>
  </div>
  <?php
    }
  ?>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script type="text/javascript" src="../letsmit/js/homescripts.js"></script>
  </body>
  </html>
