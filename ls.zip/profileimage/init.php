<br />
<b>Warning</b>:  require_once(functions/sanitize.php): failed to open stream: No such file or directory in <b>C:\xampp\htdocs\letsmit\core\init.php</b> on line <b>24</b><br />
<br />
<b>Fatal error</b>:  require_once(): Failed opening required 'functions/sanitize.php' (include_path='C:\xampp\php\PEAR') in <b>C:\xampp\htdocs\letsmit\core\init.php</b> on line <b>24</b><br />
